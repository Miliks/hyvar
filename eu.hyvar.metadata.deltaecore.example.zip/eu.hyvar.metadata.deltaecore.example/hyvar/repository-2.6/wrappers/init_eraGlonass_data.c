#include <stdlib.h>
#include <string.h>
#include "sc_types.h"
#include "ECall.h"
#include "ECallRequired.h"
#include "init_data.h"

/*! \file Implementation of the function 'eCallIfaceFunc_init_eraGlonassData'
*/

sc_integer eCallIfaceFunc_init_eraGlonass_data(const ECall* handle)
{
	printf("eCallIfaceFunc_init_eraGlonass_data\n");
	
	ECALLMessage_t* ptr = (ECALLMessage_t*) (handle->ifaceFunc.proxy);
	init_eraGlonassData(ptr);
}
