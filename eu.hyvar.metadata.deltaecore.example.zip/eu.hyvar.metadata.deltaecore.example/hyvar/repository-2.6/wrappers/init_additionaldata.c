#include <stdlib.h>
#include <string.h>
#include "sc_types.h"
#include "ECall.h"
#include "ECallRequired.h"
#include "ecallmessage.h"
#include "asn1.h"
#include "additionaldata.h"

/*! \file Implementation of the function 'eCallIfaceFunc_init_additionaldata'
*/

sc_integer eCallIfaceFunc_init_additionaldata(const ECall* handle)
{
	printf("eCallIfaceFunc_init_additionaldata\n");
	ECALLMessage_t* ptr = (ECALLMessage_t*) (handle->ifaceFunc.proxy);
	//init_additionaldata((ptr->msd->optionalAdditionalData));
}
