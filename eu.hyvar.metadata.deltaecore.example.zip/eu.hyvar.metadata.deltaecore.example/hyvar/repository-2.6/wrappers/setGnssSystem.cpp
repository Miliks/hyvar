#include <stdlib.h>
#include <string.h>
#include "sc_types.h"
#include "ECall.h"
#include "ECallRequired.h"
#include "init_data.h"
#include "ATB2.h"

/*! \file Implementation of the function 'eCallIfaceFunc_setGnssSystem'
*/

sc_integer eCallIfaceFunc_setGnssSystem(const ECall* handle)
{
	printf("eCallIfaceFunc_setGnssSystem\n");
	setGnssSystem((gnss_e) handle->ifaceData.GNSS);
}
