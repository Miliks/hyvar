#include <stdlib.h>
#include <string.h>
#include "sc_types.h"
#include "ECall.h"
#include "ECallRequired.h"
#include "asn1.h"
#include "ecallmessage.h"

/*! \file Implementation of the function 'eCallIfaceFunc_init_ecallmessage'
*/

sc_integer eCallIfaceFunc_init_ecallmessage(const ECall* handle)
{
	printf("eCallIfaceFunc_init_ecallmessage\n");
	ECALLMessage_t* ptr = (ECALLMessage_t*) (handle->ifaceFunc.proxy);
	init_ecallmessage(ptr);
}
