#include <stdio.h>
#include "ecallmessage.h"
#include "ECall.h"
#include "ECallRequired.h"
#include "config.h"

/* moving this variable inside the main causes segmentation fault*/
ECALLMessage_t ecallMessage;


asnint main(int argc, char *argv[]) {
	asnint a = 8;
	asn1msd_t buffer;

	ECall handle;
	eCall_init (&handle);

	// Cast the ecallMessage data inside the handle struct
	(&handle)->ifaceFunc.proxy = (intptr_t) &ecallMessage;
	
	// Initializes the buffer
	buffer.bitno = 0;
	for (a = 0; a < 140; a++) buffer.msd[a] = (unsigned char)0x00;
	(&handle)->ifaceFunc.buffer = (intptr_t) &buffer;

	eCall_enter (&handle);
	while(!eCall_isFinal(&handle)) {
		eCall_runCycle (&handle);
	}
	
	printf("New main Loop\n");

	// Just prints the encoded bytes
	asn1msd_t* buffer_3 = (asn1msd_t*) (&handle.ifaceFunc.buffer);
	for (a = 0;
		 a < (((*buffer_3).bitno / 8) + (((*buffer_3).bitno%8)?1:0));
		 a++)
		printf("%02x ", (unsigned char)(*buffer_3).msd[a]);
		printf("\n");

	system("pause");

	return 1;
}
