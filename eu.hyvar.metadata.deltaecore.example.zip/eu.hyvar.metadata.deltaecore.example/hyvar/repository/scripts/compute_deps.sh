#!/bin/sh
# $0 is the script name, $1 id the first ARG, $2 is second...
INPUT_C=$1
WRAPPER=${INPUT_C%.*}
echo "wrapper: ${WRAPPER}"
make -f deps.mk wrapper FILE_NAME="${WRAPPER}" CFLAGS=-I../include CFLAGS+=-I../../europe/src
