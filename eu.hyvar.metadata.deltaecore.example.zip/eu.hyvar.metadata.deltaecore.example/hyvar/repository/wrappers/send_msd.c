#include <stdlib.h>
#include <string.h>
#include "sc_types.h"
#include "ECall.h"
#include "ECallRequired.h"
#include "ecallmessage.h"
#include "init_data.h"

/*! \file Implementation of the function 'eCallIfaceFunc_send_msd'
*/

sc_integer eCallIfaceFunc_send_msd(ECall* handle)
{
	printf("eCallIfaceFunc_send_msd\n");
	
	send_msd((asn1msd_t*) &(handle->ifaceFunc.buffer));
}
