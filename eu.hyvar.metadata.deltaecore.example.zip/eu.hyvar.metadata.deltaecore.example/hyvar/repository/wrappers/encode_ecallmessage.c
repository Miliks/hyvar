#include <stdlib.h>
#include <string.h>
#include "sc_types.h"
#include "ECall.h"
#include "ECallRequired.h"
#include "ecallmessage.h"
#include "init_data.h"

/*! \file Implementation of the function 'eCallIfaceFunc_encode_ecallmessage'
*/

sc_integer eCallIfaceFunc_encode_ecallmessage(ECall* handle)
{
	printf("eCallIfaceFunc_encode_ecallmessage\n");
	
	encode_ecallmessage((ECALLMessage_t*)(handle->ifaceFunc.proxy),(asn1msd_t*) (handle->ifaceFunc.buffer));
}
