#include <stdlib.h>
#include <string.h>
#include "sc_types.h"
#include "ECall.h"
#include "ECallRequired.h"
#include "ecallmessage.h"
#include "init_data.h"

/*! \file Implementation of the function 'eCallIfaceFunc_play_prompt'
*/

sc_integer eCallIfaceFunc_play_prompt(ECall* handle)
{
	printf("eCallIfaceFunc_play_prompt\n");
	
	play_prompt();
}
