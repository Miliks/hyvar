#include <stdlib.h>
#include <string.h>
#include "sc_types.h"
#include "ECall.h"
#include "ECallRequired.h"
#include "init_data.h"

/*! \file Implementation of the function 'eCallIfaceFunc_setLanguage'
*/

sc_integer eCallIfaceFunc_setLanguage(ECall* handle)
{
	printf("eCallIfaceFunc_setLanguage\n");
	setLanguage(handle->ifaceData.Language);
}
