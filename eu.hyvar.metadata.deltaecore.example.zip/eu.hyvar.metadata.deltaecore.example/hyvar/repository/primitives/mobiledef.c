#include <stdio.h>
#include "asn1.h"
#include "mobiledef.h"

void init_mobiledef(MobileDef_t *message) {
	message->eramcc = MIN_ERAMCC;
	message->eramncsid = MIN_ERAMNCSID;
	message->eralacnid = MIN_ERALACNID;
	message->aracidbid = MIN_ERACIDBID;
	message->erasector = MIN_ERASECTOR;
	message->erassi = MIN_ERASSI;

	return;
}

/**
* Encode the mobiledef. 
eramcc          INTEGER (0 .. 999),
eramncsid       INTEGER (0 .. 16383),
eralacnid       INTEGER (0 .. 65535),
eracidbid       INTEGER (0 .. 65535),
erasector	INTEGER (0 .. 255),
erarssi 	INTEGER (-150..0)
*/
asnint encode_mobiledef(MobileDef_t *message, asn1msd_t *buffer) {
	asnint r = 0;

	if (NULL == message) return -1;

	r += encode_constrained_whole_number(message->eramcc, MIN_ERAMCC, MAX_ERAMCC, buffer);

	r += encode_constrained_whole_number(message->eramncsid, MIN_ERAMNCSID,	MAX_ERAMNCSID, buffer);

	r += encode_constrained_whole_number(message->eralacnid, MIN_ERALACNID, MAX_ERALACNID, buffer);

	r += encode_constrained_whole_number(message->aracidbid, MIN_ERACIDBID, MAX_ERACIDBID, buffer);

	r += encode_constrained_whole_number(message->erasector, MIN_ERASECTOR, MAX_ERASECTOR, buffer);

	r += encode_constrained_whole_number(message->erassi, MIN_ERASSI, MAX_ERASSI, buffer);

	return r;
}

/**
* Decodes the vehicle mobiledef type. This method is not implemented.
*/
asnint asnintdecode_mobiledef(MobileDef_t *message, asn1msd_t *buffer) {
	asnint r = -1;

	return r;
}
