#ifndef	__TESTRESULT_DEF_H_
#define __TESTRESULT_DEF_H_

#ifdef __cplusplus
extern "C" {
#endif


	/** This structure contains the TestResult structure which is one of the optional fields
	of the Optional Data of the MSD
	TestResultsDef ::= SEQUENCE {
	micconnectionfailure BOOLEAN DEFAULT FALSE,
	micfailure BOOLEAN DEFAULT FALSE,
	rightspeakerfailure BOOLEAN DEFAULT FALSE,
	leftspeakerfailure BOOLEAN DEFAULT FALSE,
	speakersfailure BOOLEAN DEFAULT FALSE,
	ignitionlinefailure BOOLEAN DEFAULT FALSE,
	uimfailure BOOLEAN DEFAULT FALSE,
	statusindicatorfailure BOOLEAN DEFAULT FALSE,
	batteryfailure BOOLEAN DEFAULT FALSE,
	batteryvoltagelow BOOLEAN DEFAULT FALSE,
	crashsensorfailure BOOLEAN DEFAULT FALSE,
	swimagecorruption BOOLEAN DEFAULT FALSE,
	commmoduleinterfacefailure BOOLEAN DEFAULT FALSE,
	gnssreceiverfailure BOOLEAN DEFAULT FALSE,
	raimproblem BOOLEAN DEFAULT FALSE,
	gnssantennafailure BOOLEAN DEFAULT FALSE,
	commmodulefailure BOOLEAN DEFAULT FALSE,
	eventsmemoryoverflow BOOLEAN DEFAULT FALSE,
	crashprofilememoryoverflow BOOLEAN DEFAULT FALSE,
	othercriticalfailires BOOLEAN DEFAULT FALSE,
	othernotcriticalfailures BOOLEAN DEFAULT FALSE
	}

	*/
	typedef struct TestResultDef {
		asnbool micconnectionfailure;
		asnbool micfailure;
		asnbool rightspeakerfailure;
		asnbool leftspeakerfailure;
		asnbool speakersfailure;
		asnbool ignitionlinefailure;
		asnbool uimfailure;
		asnbool statusindicatorfailure;
		asnbool batteryfailure;
		asnbool batteryvoltagelow;
		asnbool crashsensorfailure;
		asnbool swimagecorruption;
		asnbool commmoduleinterfacefailure;
		asnbool gnssreceiverfailure;
		asnbool raimproblem;
		asnbool gnssantennafailure;
		asnbool commmodulefailure;
		asnbool eventsmemoryoverflow;
		asnbool crashprofilememoryoverflow;
		asnbool othercriticalfailures;
		asnbool othernotcriticalfailures;
	} TestResultDef_t;

	extern void init_testresultdef(TestResultDef_t *message);
	extern asnint encode_testresultdef(TestResultDef_t *message, asn1msd_t *buffer);
	extern asnint decode_testresultdef(TestResultDef_t *message, asn1msd_t *buffer);

#ifdef __cplusplus
}
#endif

#endif	/* __TESTRESULT_DEF_H_ */
