#ifndef	_VehicleLocationDelta_H_
#define	_VehicleLocationDelta_H_

#ifdef __cplusplus
extern "C" {
#endif

#define MIN_LATITUDEDELTA  -512LL
#define MAX_LATITUDEDELTA   511LL
#define MIN_LONGITUDEDELTA -512LL
#define MAX_LONGITUDEDELTA  511LL
/*
 * VehicleLocationDelta ::= SEQUENCE {
 * 		latitudeDelta  INTEGER(-512..511)
 * 		asnllongitudeDelta INTEGER(-512..511)
 * 		}
 */
typedef struct VehicleLocationDelta {
	asnllong 	latitudeDelta;
	asnllong 	longitudeDelta;
} VehicleLocationDelta_t;

extern void init_vehiclelocationdelta(VehicleLocationDelta_t *message);
extern asnint encode_vehiclelocationdelta(VehicleLocationDelta_t *message, asn1msd_t *buffer);
extern asnint decode_vehiclelocationdelta(VehicleLocationDelta_t *message, asn1msd_t *buffer);

#ifdef __cplusplus
}
#endif

#endif
