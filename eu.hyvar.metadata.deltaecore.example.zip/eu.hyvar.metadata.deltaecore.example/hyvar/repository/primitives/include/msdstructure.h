#ifndef	_MSDStructure_H_
#define	_MSDStructure_H_

/* Including external dependencies */
#include "asn1.h"
#include "controltype.h"
#include "vin.h"
#include "vehiclepropulsionstoragetype.h"
#include "vehiclelocation.h"
#include "vehiclelocationdelta.h"

#ifdef __cplusplus
extern "C" {
#endif


/* MSDStructure 
MSDStructure ::= SEQUENCE {
		messageIdentifier INTEGER(0 .. 255),
		control ControlType,
		vehicleIdentificationNumber VIN,
		vehiclePropulsionStorageType VehiclePropulsionStorageType,
		timestamp INTEGER(0 .. 4294967295),
		vehicleLocation VehicleLocation,
		vehicleDirection INTEGER(0 .. 255),
		recentVehicleLocationN1 VehicleLocationDelta OPTIONAL,
		recentVehicleLocationN2 VehicleLocationDelta OPTIONAL,
		numberOfPassengers INTEGER(0 .. 255) OPTIONAL,
		...
	} 
 */
typedef struct MSDStructure {
	asnllong	 messageIdentifier;
	ControlType_t	 control;
	VIN_t	 vehicleIdentificationNumber;
	VehiclePropulsionStorageType_t	 vehiclePropulsionStorageType;
	asnllong	 timestamp;
	VehicleLocation_t	 vehicleLocation;
	asnllong	 vehicleDirection;

	asnbool recentVehicleLocationN1Present;
	struct VehicleLocationDelta	recentVehicleLocationN1	/* OPTIONAL */;

	asnbool recentVehicleLocationN2Present;
	struct VehicleLocationDelta	recentVehicleLocationN2	/* OPTIONAL */;

	asnbool  numberOfPassengersPresent;
	asnllong numberOfPassengers	/* OPTIONAL */;

	/*
	 * This type is extensible,
	 * possible extensions are below.
	 */
	
} MSDStructure_t;

extern void init_msdstructure(MSDStructure_t *message);
extern asnint encode_msdstructure(MSDStructure_t *message, asn1msd_t *buffer);
extern asnint decode_msdstructure(MSDStructure_t *message, asn1msd_t *buffer);

#ifdef __cplusplus
}
#endif

#endif	/* _MSDStructure_H_ */
