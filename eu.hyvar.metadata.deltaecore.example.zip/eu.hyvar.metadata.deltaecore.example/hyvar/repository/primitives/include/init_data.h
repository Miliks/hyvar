#include <stdio.h>
#include "ecallmessage.h"

asnbool init_ecalldata(ECALLMessage_t *ecallMessage);
asnint init_eraGlonassData(ECALLMessage_t *ecallMessage);
