#ifndef	__ADDITIONAL_DATA_H_
#define __ADDITIONAL_DATA_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "mobiledef.h"
#include "testresultdef.h"
#include "crashdef.h"


#define OID_ADDITIONAL_DATA_LENTH 8
#define ID_ADDITIONAL_DATA_LENTH 8



/** This structure contains additional data that can be added to the payload of the MSD.
	Right now, the encoding of the additional data is not implemented, if used, this field
	should be provided already encoded in ASN1.PER unaligned format.
*/
typedef struct AdditionalData {
	// Header, presence od optional fields inside the Additional Data Structure
	asnbool				MobileDefPresence;
	asnbool				TestResultsDefPresence;
	asnbool				CrashDefPresence;

	// Fields
	asnbit					oid[OID_ADDITIONAL_DATA_LENTH];
	asnbit					id[ID_ADDITIONAL_DATA_LENTH];
	asnbool					severecrashestimation;
	struct MobileDef		mobiledef;
	struct TestResultDef	testresultdef;
	struct CrashDef			crashdef;

} AdditionalData_t;

extern void init_additionaldata(AdditionalData_t *message);
extern asnint encode_additionaldata(AdditionalData_t *message, asn1msd_t *buffer);
extern asnint decode_additionaldata(AdditionalData_t *message, asn1msd_t *buffer);

#ifdef __cplusplus
}
#endif

#endif	/* _AdditionalData_H_ */
