#ifndef	_ControlType_H_
#define	_ControlType_H_


#include "vehicletype.h"

#ifdef __cplusplus
extern "C" {
#endif

/* 
	ControlType  ::= SEQUENCE {
		automaticActivation BOOLEAN,
		testCall BOOLEAN,
		positionCanBeTrusted BOOLEAN,
		vehicleType VehicleType
	}
*/
typedef struct ControlType {
	asnbool	 automaticActivation;
	asnbool	 testCall;
	asnbool	 positionCanBeTrusted;
	VehicleType_t	 vehicleType; 
	
} ControlType_t;

extern void init_controltype(ControlType_t *message);
extern asnint encode_controltype(ControlType_t *message, asn1msd_t *buffer);
extern asnint decode_controltype(ControlType_t *message, asn1msd_t *buffer);

#ifdef __cplusplus
}
#endif

#endif	/* _ControlType_H_ */
