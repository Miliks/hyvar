#ifndef	_VehicleType_H_
#define	_VehicleType_H_


#ifdef __cplusplus
extern "C" {
#endif

/* 
 * ASN.1
	VehicleType ::= ENUMERATED{
		passengerVehicleClassM1 (1),
		busesAndCoachesClassM2 (2),
		busesAndCoachesClassM3 (3),
		lightCommercialVehiclesClassN1 (4),
		heavyDutyVehiclesClassN2 (5),
		heavyDutyVehiclesClassN3 (6),
		motorcyclesClassL1e (7),
		motorcyclesClassL2e (8),
		motorcyclesClassL3e (9),
		motorcyclesClassL4e (10),
		motorcyclesClassL5e (11),
		motorcyclesClassL6e (12),
		motorcyclesClassL7e (13),
		...
	}
*/
typedef enum VehicleType {
	VehicleType_passengerVehicleClassM1	= 1,
	VehicleType_busesAndCoachesClassM2	= 2,
	VehicleType_busesAndCoachesClassM3	= 3,
	VehicleType_lightCommercialVehiclesClassN1	= 4,
	VehicleType_heavyDutyVehiclesClassN2	= 5,
	VehicleType_heavyDutyVehiclesClassN3	= 6,
	VehicleType_motorcyclesClassL1e	= 7,
	VehicleType_motorcyclesClassL2e	= 8,
	VehicleType_motorcyclesClassL3e	= 9,
	VehicleType_motorcyclesClassL4e	= 10,
	VehicleType_motorcyclesClassL5e	= 11,
	VehicleType_motorcyclesClassL6e	= 12,
	VehicleType_motorcyclesClassL7e	= 13
	/*
	 * Enumeration is extensible
	 */
} e_VehicleType;

/* It's the min and max value of the vehicle type inside the root values */
#define MIN_VEHICLETYPE_RANGE VehicleType_passengerVehicleClassM1
#define MAX_VEHICLETYPE_RANGE VehicleType_motorcyclesClassL7e

/* VehicleType */
typedef asnllong	 VehicleType_t;


extern void init_vehicletype(VehicleType_t  *message);
extern asnint encode_vehicletype(VehicleType_t *message, asn1msd_t *buffer);
extern asnint decode_vehicletype(VehicleType_t *message, asn1msd_t *buffer);

#ifdef __cplusplus
}
#endif

#endif	/* _VehicleType_H_ */
