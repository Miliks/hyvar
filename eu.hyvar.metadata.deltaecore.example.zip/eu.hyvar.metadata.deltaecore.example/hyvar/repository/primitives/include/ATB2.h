/*
 * ATB2.h
 *
 * Interface to ATB2 sensor data
 */
#ifndef ATB2_H_
#define ATB2_H_

/*
#include <boost/interprocess/shared_memory_object.hpp>
#include <boost/interprocess/mapped_region.hpp>
#include <boost/interprocess/sync/scoped_lock.hpp>
#include <boost/interprocess/sync/interprocess_mutex.hpp>
*/
//#include <cstring>


#include "string.h"

#include "vehicletype.h"
#include "testresultdef.h"
#define SHARED_MEMORY_NAME "ExtractedGPSData"
#define LATLON_CONVERSION_FACTOR 3600000

//using namespace boost::interprocess;

typedef struct sat_data
{
	float latitude;
	float longitude;
	int speed;
	int altitude;
	int direction;
	int satellites;
	int hdop;
//	bool gpsStatus;
	char timestamp[50];

//	bool update_request;

	//Mutex to protect memory access
//	boost::interprocess::interprocess_mutex mutex;
} sat_data_t;


typedef enum {
	COMBINED_1 = 0,
	GPS_1 = 1,
	GLONASS_1 = 2
}gnss_e;

typedef enum {
	Bulgarian,
	Croatian,
	Czech,
	Danish,
	Dutch,
	English,
	Estonian,
	Finnish,
	French,
	German,
	Greek,
	Hungarian,
	Irish,
	Italian,
	Latvian,
	Lithuanian,
	Maltese,
	Polish,
	Portuguese,
	Romanian,
	Slovak,
	Slovenian,
	Spanish,
	Swedish,
	Russian
}languages_e;


#ifdef __cplusplus
extern "C" {
#endif


extern void ATB2init();
extern VehicleType_t getATB2VehicleType();
extern int getATB2NumberOfPassengers();


extern long getATB2PositionLatitude();
extern long getATB2PositionLongitude();
extern int getATB2VehicleDirection();
extern long getATB2Timestamp();

extern int getATB2GasolineTankPresent();
extern int getATB2ElectricEnergyStorage();

extern int getATBRecentVehicleLocationN1Present();
extern int getATBRecentVehicleLocationN2Present();
extern asnllong getATBRecentVehicleLocationN1latitudeDelta();
extern asnllong getATBRecentVehicleLocationN2latitudeDelta();
extern asnllong getATBRecentVehicleLocationN1longitudeDelta();
extern asnllong getATBRecentVehicleLocationN2longitudeDelta();

extern void setGnssSystem(gnss_e gnss);
extern void setLanguage(languages_e language);
extern void send_msd(asn1msd_t *buffer);
extern void call112();
extern void play_prompt();
extern void getAutoDiagResults(TestResultDef_t *testresultdef);
extern asnlong getMCC();
extern asnlong getRSSI();

#ifdef __cplusplus
        }
#endif

#endif /* ATB2_H_ */
