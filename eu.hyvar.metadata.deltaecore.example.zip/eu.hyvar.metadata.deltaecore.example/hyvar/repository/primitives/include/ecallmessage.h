#ifndef	_ECALLMessage_H_
#define	_ECALLMessage_H_


/* Including external dependencies */
#include "msdmessage.h"

#ifdef __cplusplus
extern "C" {
#endif

/* MSDMessage */
typedef struct ECALLMessage {
	asnllong			id;	// Integer (0..255)
	MSDMessage_t	msd;

} ECALLMessage_t;

extern void init_ecallmessage(ECALLMessage_t *message);
extern asnint encode_ecallmessage(ECALLMessage_t *message, asn1msd_t *buffer);
extern asnint decode_ecallmessage(ECALLMessage_t *message, asn1msd_t *buffer);

#ifdef __cplusplus
}
#endif

#endif	/* _MSDMessage_H_ */
