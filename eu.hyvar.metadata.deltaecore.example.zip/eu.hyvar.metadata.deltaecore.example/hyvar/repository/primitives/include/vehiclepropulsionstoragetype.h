#ifndef	_VehiclePropulsionStorageType_H_
#define	_VehiclePropulsionStorageType_H_

#ifdef __cplusplus
extern "C" {
#endif

/*
 * VehiclePropulsionStorageType ::= SEQUENCE {
 * 		gasolineTankPresent BOOLEAN DEFAULT FALSE,
 * 		dieselTankPresent BOOLEAN DEFAULT FALSE,
 * 		compressedNaturalGas BOOLEAN DEFAULT FALSE,
 * 		liquidPropaneGas BOOLEAN DEFAULT FALSE,
 * 		electricEnergyStorage BOOLEAN DEFAULT FALSE,
 * 		hydrogenStorage BOOLEAN DEFAULT FALSE,
 * 		...
 * 		}
 */
typedef struct VehiclePropulsionStorageType {
	asnbool 	gasolineTankPresent;
	asnbool 	dieselTankPresent;
	asnbool		compressedNaturalGas;
	asnbool		liquidPropaneGas;
	asnbool		electricEnergyStorage;
	asnbool		hydrogenStorage;
	/*
	 * This type is extensible,
	 * possible extensions are below.
	 */

} VehiclePropulsionStorageType_t;

extern void init_vehiclepropulsionstoragetype(VehiclePropulsionStorageType_t *message);
extern asnint encode_vehiclepropulsionstoragetype(VehiclePropulsionStorageType_t *message, asn1msd_t *buffer);
extern asnint decode_vehiclepropulsionstoragetype(VehiclePropulsionStorageType_t *message, asn1msd_t *buffer);

#ifdef __cplusplus
}
#endif

#endif
