#ifndef	_VIN_H_
#define	_VIN_H_


#ifdef __cplusplus
extern "C" {
#endif

#define VIN_ISOWMI_LENGTH			3
#define VIN_ISOVDS_LENGTH			6
#define VIN_ISOVISMODELYEAR_LENGTH	1
#define VIN_ISOVISSEQPLANT_LENGTH	7
/* 
VIN ::= SEQUENCE {
	isowmi PrintableString (SIZE(3))
		(FROM("A".."H"|"J".."N"|"P"|"R".."Z"|"0".."9")),
	isovds PrintableString (SIZE(6))
		(FROM("A".."H"|"J".."N"|"P"|"R".."Z"|"0".."9")),
	isovisModelyear PrintableString (SIZE(1))
		(FROM("A".."H"|"J".."N"|"P"|"R".."Z"|"0".."9")),
	isovisSeqPlant PrintableString (SIZE(7))
		(FROM("A".."H"|"J".."N"|"P"|"R".."Z"|"0".."9"))
}
*/
typedef struct VIN {
	char	 *isowmi; //[3];
	char	 *isovds; //[6];
	char	 *isovisModelYear; //[1];
	char	 *isovisSeqPlant; //[7];
} VIN_t;


extern void init_vin(VIN_t  *message);
extern asnint encode_vin(VIN_t *message, asn1msd_t *buffer);
extern asnint decode_vin(VIN_t *message, asn1msd_t *buffer);

#ifdef __cplusplus
}
#endif

#endif	/* _VIN_H_ */
