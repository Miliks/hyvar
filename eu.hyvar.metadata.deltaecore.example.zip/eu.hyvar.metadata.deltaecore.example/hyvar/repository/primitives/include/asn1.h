#ifndef __ECALL_H
#define __ECALL_H

#define ASN_TRUE					1
#define ASN_FALSE					0
#define EXTENSION_IN_ROOT 			1
#define EXTENSION_NOT_IN_ROOT		0
#define OPTION_PRESENT			    1
#define OPTION_NOT_PRESENT			0

#ifdef __cplusplus
extern "C" {
#endif

typedef int				asnbool;
typedef int				asnint;
typedef long			asnlong;
typedef unsigned long	asnulong;
typedef long long		asnllong;
typedef char			asnbit;

typedef struct {
	char msd[140];
	asnint bitno;
} asn1msd_t;

/**
 * Set a specific bit in the passed buffer
 * @param flag the bit to set
 * @param buffer the buffer containing the bitstring
 * @return 1 if the bit was set, 0 otherwise
 * @see asn1msd_t
 */
extern asnint setBit(asnbool flag, asn1msd_t *buffer);
extern asnint getBit(asnbool *bit, asn1msd_t *buffer);

extern asnint setBits(asnint bits, asnllong number, asn1msd_t *buffer);
extern asnint getBits(asnint bits, asnllong *number, asn1msd_t *buffer);

/**
 * Adds bitno number of bits into the buffer.
 * @param frombits the buffer containing the bits to be added to the buffer
 * @param buffer the buffer of type asn1msd_t
 * @param bitno the number of bits to be copied into the buffer
 * @return the number of bits inserted. The bumber of bits currently in the buffer is also modified
 * @see asn1msd_t
 */
extern asnint addBits(char *frombits, asn1msd_t *buffer, asnint bitno);

/**
 * Encodes the ASN.1 BOOLEAN type.
 * @param value the boolean to encode. Either ASN_TRUE or ASN_FALSE.
 * @param buffer the buffer containing the encoding
 * @return the number of bit written: 1 in this case
 * @see asnbool
 * @see asn1msd_t
 */
extern asnint encode_boolean(asnbool flag,  asn1msd_t *buffer);
extern asnint decode_boolean(asnbool *flag, asn1msd_t *buffer);

/**
 * Cfr. 10.5 constrained whole number: normally small non-negative whole number
 * This is a number with a specific lower and upper bound, in this case the minimum number
 * of bits needed to represent the range is used.
 * @param number the integer to represent
 * @param lowerbound the lower bound of the range
 * @param upperbound the upperbound of the range
 * @buffer the buffer where data are stored
 * @see asn1msd_t
 */
extern asnint encode_constrained_whole_number(asnllong number, asnllong lowerbound, asnllong upperbound, asn1msd_t *buffer);
extern asnint decode_constrained_whole_number(asnllong *number, asnllong lowerbound, asnllong upperbound, asn1msd_t *buffer);

extern asnint encode_length_determinant(asnint length, asn1msd_t *buffer);
extern asnint encode_normally_small_non_negative_whole_number(asnllong number, asn1msd_t *buffer);
extern asnint encode_semi_constrained_whole_number(asnllong number, asnllong lowerbound, asn1msd_t *buffer);
extern asnint encode_unconstrained_whole_number(asnllong number, asn1msd_t *buffer);


extern asnint encodePrintableStringWithPattern(char *pattern, asnint patternlength, char *string, asnint strlength, asn1msd_t *buffer);

extern asnint addExtensionBit(asnint is_in_root, asn1msd_t *buffer);
extern asnint getExtensionBit(asnint *is_in_root, asn1msd_t *buffer);

extern asnint addOptionalBit(asnint presence, asn1msd_t *buffer);
extern asnint getOptionalBit(asnint *presence, asn1msd_t *buffer);

extern asnint encodeEnumeration(asnllong value, asnllong lowerbound, asnllong upperbound, asnbool isinroot, asn1msd_t *buffer);
extern asnint decodeEnumeration(asnllong *value, asnllong lowerbound, asnllong upperbound, asnbool isinroot, asn1msd_t *buffer);

/**
 * Encodes a bitstring into the specified buffer
 * @param value The bitstring to be encoded
 * @param length The bitstring length (in number of bits)
 * @param buffer The buffer where the encoding will be stored
*/
extern asnint encodeBitString(asnbit *value, asnint length, asn1msd_t *buffer);

#ifdef __cplusplus
}
#endif


#endif

/*
MSDASN1Module
DEFINITIONS
AUTOMATIC TAGS ::=
BEGIN

ECallMessage ::= SEQUENCE {
id INTEGER(0 .. 255),
msd MSDMessage
}
MSDMessage ::= SEQUENCE {
msdStructure MSDStructure,
optionalAdditionalData AdditionalData OPTIONAL,
...
}
MSDStructure ::= SEQUENCE {
messageIdentifier INTEGER(0 .. 255),
control ControlType,
vehicleIdentificationNumber VIN,
vehiclePropulsionStorageType VehiclePropulsionStorageType,
timestamp INTEGER(0 .. 4294967295),
vehicleLocation VehicleLocation,
vehicleDirection INTEGER(0 .. 255),
recentVehicleLocationN1 VehicleLocationDelta OPTIONAL,
recentVehicleLocationN2 VehicleLocationDelta OPTIONAL,
numberOfPassengers INTEGER(0 .. 255) OPTIONAL,
...
}
ControlType ::= SEQUENCE {
automaticActivation BOOLEAN,
testCall BOOLEAN,
positionCanBeTrusted BOOLEAN,
vehicleType VehicleType
}
VehicleType ::= ENUMERATED{
passengerVehicleClassM1 (1),
busesAndCoachesClassM2 (2),
busesAndCoachesClassM3 (3),
lightCommercialVehiclesClassN1 (4),
heavyDutyVehiclesClassN2 (5),
heavyDutyVehiclesClassN3 (6),
motorcyclesClassL1e (7),
motorcyclesClassL2e (8),
motorcyclesClassL3e (9),
motorcyclesClassL4e (10),
motorcyclesClassL5e (11),
motorcyclesClassL6e (12),
motorcyclesClassL7e (13),
...
}

VIN ::= SEQUENCE {
isowmi PrintableString (SIZE(3))
(FROM("A".."H"|"J".."N"|"P"|"R".."Z"|"0".."9")),
isovds PrintableString (SIZE(6))
(FROM("A".."H"|"J".."N"|"P"|"R".."Z"|"0".."9")),
isovisModelyear PrintableString (SIZE(1))
(FROM("A".."H"|"J".."N"|"P"|"R".."Z"|"0".."9")),
isovisSeqPlant PrintableString (SIZE(7))
(FROM("A".."H"|"J".."N"|"P"|"R".."Z"|"0".."9"))
}

VehiclePropulsionStorageType ::= SEQUENCE {
gasolineTankPresent BOOLEAN DEFAULT FALSE,
dieselTankPresent BOOLEAN DEFAULT FALSE,
compressedNaturalGas BOOLEAN DEFAULT FALSE,
liquidPropaneGas BOOLEAN DEFAULT FALSE,
electricEnergyStorage BOOLEAN DEFAULT FALSE,
hydrogenStorage BOOLEAN DEFAULT FALSE,
...
}

VehicleLocation ::= SEQUENCE {
positionLatitude INTEGER(-2147483648..2147483647),
positionasnllongitude INTEGER(-2147483648..2147483647)
}
VehicleLocationDelta ::= SEQUENCE {
latitudeDelta INTEGER (-512..511),
asnllongitudeDelta INTEGER (-512..511)
}

AdditionalData ::= SEQUENCE {
oid RELATIVE-OID,
data OCTET STRING
}

END
*/
