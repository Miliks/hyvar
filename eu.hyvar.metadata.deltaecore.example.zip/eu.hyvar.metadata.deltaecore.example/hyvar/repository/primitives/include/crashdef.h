#ifndef	__CRASH_DEF_H_
#define __CRASH_DEF_H_

#ifdef __cplusplus
extern "C" {
#endif


	/** This structure contains the CrashDef structure which is one of the optional fields
	of the Optional Data of the MSD
	CrashDef ::= SEQUENCE {
	crashfront BOOLEAN DEFAULT FALSE,
	crashside BOOLEAN DEFAULT FALSE,
	crashfrontorside BOOLEAN DEFAULT FALSE,
	crashrear BOOLEAN DEFAULT FALSE,
	crashrollover BOOLEAN DEFAULT FALSE,
	crashanothertype BOOLEAN DEFAULT FALSE
	}

	*/
	typedef struct CrashDef {
		asnbool crashfront;
		asnbool crashside;
		asnbool crashfrontorside;
		asnbool crashrear;
		asnbool crashrollover;
		asnbool crashanothertype;
	} CrashDef_t;

	extern void init_crashdef(CrashDef_t *message);
	extern asnint encode_crashdef(CrashDef_t *message, asn1msd_t *buffer);
	extern asnint decode_crashdef(CrashDef_t *message, asn1msd_t *buffer);

#ifdef __cplusplus
}
#endif

#endif	/* __CRASH_DEF_H_ */
