#ifndef	_MSDMessage_H_
#define	_MSDMessage_H_


/* Including external dependencies */
#include "msdstructure.h"
#include "additionaldata.h"

#if HAVE_CONFIG_H
# include <config.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* Forward declarations */
struct AdditionalData;

/* MSDMessage 

MSDMessage ::= SEQUENCE {
	msdStructure MSDStructure,
	optionalAdditionalData AdditionalData OPTIONAL,
	...
 }

 */
typedef struct MSDMessage {
	asnbool optionalAdditionalDataPresent;
	struct	MSDStructure		msdStructure;

#if defined(ERAGLONASS)
	struct	AdditionalData		optionalAdditionalData;	/* OPTIONAL */
#endif

	/*
	 * This type is extensible,
	 * possible extensions are below.
	 */

} MSDMessage_t;

extern void init_msdmessage(MSDMessage_t *message);
extern asnint encode_msdmessage(MSDMessage_t *message, asn1msd_t *buffer);
extern asnint decode_msdmessage(MSDMessage_t *message, asn1msd_t *buffer);

#ifdef __cplusplus
}
#endif

#endif	/* _MSDMessage_H_ */
