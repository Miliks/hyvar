#ifndef	_VehicleLocation_H_
#define	_VehicleLocation_H_

#ifdef __cplusplus
extern "C" {
#endif

#define MIN_POSITIONLATITUDE  -2147483648LL
#define MAX_POSITIONLATITUDE   2147483647LL
#define MIN_POSITIONLONGITUDE -2147483648LL
#define MAX_POSITIONLONGITUDE  2147483647LL
/*
 * VehicleLocation ::= SEQUENCE {
 * 		positionLatitude  INTEGER(-2147483648..2147483647)
 * 		positionasnllongitude INTEGER(-2147483648..2147483647)
 * 		}
 */
typedef struct VehicleLocation {
	asnllong positionLatitude;
	asnllong positionLongitude;
} VehicleLocation_t;

extern void init_vehiclelocation(VehicleLocation_t *message);
extern asnint encode_vehiclelocation(VehicleLocation_t *message, asn1msd_t *buffer);
extern asnint decode_vehiclelocation(VehicleLocation_t *message, asn1msd_t *buffer);

#ifdef __cplusplus
}
#endif

#endif
