#ifndef	__MOBILE_DEF_H_
#define __MOBILE_DEF_H_

#ifdef __cplusplus
extern "C" {
#endif

#define		MIN_ERAMCC		0
#define		MAX_ERAMCC		999
#define		MIN_ERAMNCSID	0
#define		MAX_ERAMNCSID	16383
#define		MIN_ERALACNID	0
#define		MAX_ERALACNID	65535
#define		MIN_ERACIDBID	0
#define		MAX_ERACIDBID	65535
#define		MIN_ERASECTOR	0
#define		MAX_ERASECTOR	255
#define		MIN_ERASSI		-150
#define		MAX_ERASSI		0

	/** This structure contains the MobileDef structure which is one of the optional fields
	of the Optional Data of the MSD
	MobileDef::= SEQUENCE {
	eramcc          INTEGER (0 .. 999),
	eramncsid       INTEGER (0 .. 16383),
	eralacnid       INTEGER (0 .. 65535),
	eracidbid       INTEGER (0 .. 65535),
	erasector	INTEGER (0 .. 255),
	erarssi 	INTEGER (-150..0)
	}
	*/
	typedef struct MobileDef {
		asnlong eramcc;
		asnlong	eramncsid;
		asnlong	eralacnid;
		asnlong	aracidbid;
		asnlong	erasector;
		asnlong	erassi;

	} MobileDef_t;

	extern void init_mobiledef(MobileDef_t *message);
	extern asnint encode_mobiledef(MobileDef_t *message, asn1msd_t *buffer);
	extern asnint decode_mobiledef(MobileDef_t *message, asn1msd_t *buffer);

#ifdef __cplusplus
}
#endif

#endif	/* _AdditionalData_H_ */
