#include <stdio.h>
#include "asn1.h"
#include "crashdef.h"

/**
* Initializes the CrashDef with default values
*/

void init_crashdef(CrashDef_t *message) {
	message->crashfront = ASN_FALSE;
	message->crashside = ASN_FALSE;
	message->crashfrontorside = ASN_FALSE;
	message->crashrollover = ASN_FALSE;
	message->crashrear = ASN_FALSE;
	message->crashanothertype = ASN_FALSE;

	return;
}

/**
* Encodes the testresultdef
*/
asnint encode_crashdef(CrashDef_t *message, asn1msd_t *buffer) {
	asnint r = 0;

	/** SInce all values are defaulted to false, it writes down only
	those which are set to true */

	/** Let's write the header sayng which fields are present and which not */
	r += setBit(message->crashfront, buffer);
	r += setBit(message->crashside, buffer);
	r += setBit(message->crashfrontorside, buffer);
	r += setBit(message->crashrollover, buffer);
	r += setBit(message->crashrear, buffer);
	r += setBit(message->crashanothertype, buffer);

	// Let's write the actual values
	if (ASN_TRUE == message->crashfront)		r += setBit(message->crashfront, buffer);
	if (ASN_TRUE == message->crashside)			r += setBit(message->crashside, buffer);
	if (ASN_TRUE == message->crashfrontorside)	r += setBit(message->crashfrontorside, buffer);
	if (ASN_TRUE == message->crashrollover)		r += setBit(message->crashrollover, buffer);
	if (ASN_TRUE == message->crashrear)			r += setBit(message->crashrear, buffer);
	if (ASN_TRUE == message->crashanothertype)	r += setBit(message->crashanothertype, buffer);

	return r;
}

/**
* Decoding is not implemented
*/
asnint decode_crashdef(CrashDef_t *message, asn1msd_t *buffer) {
	asnint r = 0;

	r += getBit(&message->crashfront, buffer);
	r += getBit(&message->crashside, buffer);
	r += getBit(&message->crashfrontorside, buffer);
	r += getBit(&message->crashrollover, buffer);
	r += getBit(&message->crashrear, buffer);
	r += getBit(&message->crashanothertype, buffer);

	return r;
}
