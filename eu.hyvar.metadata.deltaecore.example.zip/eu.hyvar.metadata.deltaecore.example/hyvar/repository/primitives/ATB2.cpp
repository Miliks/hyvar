
#include "asn1.h"
#include "ATB2.h"
#include <stdio.h>
#include <stdlib.h>

//using namespace boost::interprocess;

sat_data_t * GPSDataExchange;

extern void ATB2init()
{
/*	//try {
	printf("ATB2init(): declaring shared memory\n");
	shared_memory_object shm(open_only, SHARED_MEMORY_NAME, read_write);

	//printf("ATB2init(): truncating size of shared memory\n");
	//shm.truncate(sizeof(sat_data_t));

	printf("ATB2init(): mapping region \n");
	mapped_region region(shm, read_write);
	GPSDataExchange = static_cast<sat_data_t*>(region.get_address());

	printf("ATB2init(): getting region pointer\n");
	//GPSDataExchange  = new(region.get_address())sat_data_t;

	if (NULL == GPSDataExchange)
		printf("ATB2init(): Shared memory is null\n");
	else
		printf("GPSDataExchange: 0x%x    --    0x%x\n", &GPSDataExchange, GPSDataExchange);
	printf("latitude is:%f\n", GPSDataExchange->latitude);

	//printf("ATB2init(): Shared memory is not null\n");

	//      }
	//      catch(boost::interprocess::interprocess_exception &e) {
	//        printf("ATB2init(): error: %s\n", e.what() );
	//     }
*/
}


extern VehicleType_t getATB2VehicleType() {
	return 1; //(VehicleType_t)VehicleType_passengerVehicleClassM1;
};

extern int getATB2NumberOfPassengers() {
	return 2;
};

extern long getATB2PositionLatitude()
{
/*	shared_memory_object shm(open_only, SHARED_MEMORY_NAME, read_write);
	mapped_region region(shm, read_write);
	//GPSDataExchange = static_cast<sat_data_t*>(region.get_address());
	printf("GPSDataExchange: 0x%x    --    0x%x\n", &GPSDataExchange, GPSDataExchange);
	printf("getATB2PositionLatitude: lock(GPSDataExchange->mutex)\n");
	scoped_lock<interprocess_mutex> lock(GPSDataExchange->mutex);

	printf("getATB2PositionLatitude: GPSDataExchange->latitudeXXX\n");
	printf("latitude is:%f\n", GPSDataExchange->latitude);
	float latFl = GPSDataExchange->latitude;

	printf("Latitude: %f\n", latFl);
	printf("getATB2PositionLatitude: lock.unlock()\n");
	//lock.unlock();
	long latitude = (long)(latFl*LATLON_CONVERSION_FACTOR);
	return latitude;
*/
	return 1;
}

extern long getATB2PositionLongitude()
{
/*	shared_memory_object shm(open_only, SHARED_MEMORY_NAME, read_write);
	mapped_region region(shm, read_write);
	//GPSDataExchange = static_cast<sat_data_t*>(region.get_address());

	scoped_lock<interprocess_mutex> lock(GPSDataExchange->mutex);
	float lonFl = GPSDataExchange->longitude;
	lock.unlock();
	long longitude = (long)(lonFl*LATLON_CONVERSION_FACTOR);
	return longitude;
*/
	return 1;
}

extern int getATB2VehicleDirection()
{
/*	shared_memory_object shm(open_only, SHARED_MEMORY_NAME, read_write);
	mapped_region region(shm, read_write);
	//GPSDataExchange = static_cast<sat_data_t*>(region.get_address());
	scoped_lock<interprocess_mutex> lock(GPSDataExchange->mutex);
	int direction = GPSDataExchange->direction;
	lock.unlock();
	return direction;
*/

	return 1;
}


extern long getATB2Timestamp()
{
	return 1; //(long)time(NULL);
}


extern int getATB2GasolineTankPresent(){ return 1; };
extern int getATB2ElectricEnergyStorage(){ return 1; };

extern asnbool getATBRecentVehicleLocationN1Present(){
	return ASN_TRUE;
};
extern asnbool getATBRecentVehicleLocationN2Present(){
	return ASN_TRUE;
};

extern asnllong getATBRecentVehicleLocationN1latitudeDelta(){ return 0LL; };
extern asnllong getATBRecentVehicleLocationN2latitudeDelta(){ return 0LL;  };
extern asnllong getATBRecentVehicleLocationN1longitudeDelta(){ return 0LL;  };
extern asnllong getATBRecentVehicleLocationN2longitudeDelta(){ return 0LL; };

extern asnlong getMCC() {
	return (asnllong)22;
}

extern asnlong getRSSI() {
	return (asnllong)-101L;
}

extern void getAutoDiagResults(TestResultDef_t *testresultdef) {
	testresultdef->batteryfailure = ASN_FALSE;
	testresultdef->batteryvoltagelow = ASN_FALSE;
	testresultdef->crashsensorfailure = ASN_FALSE;
}

extern void send_msd(asn1msd_t *buffer) {
	// send SMS in PDU Mode containing the passed MSD
	return;
}

extern void call112() {
	// Makes a phone call to the Police
	printf("Dialing....\n");
	system("./dial.sh");
	printf("Setting audio path...\n");
	system("./voice_call.sh");
	return;
}

extern void play_prompt()
{
	// Plays the ecall prompt.
	// This function will play different prompts for European and Era/Glonass
	// ecall.
	
	system("./playback.sh");

#ifdef ERAGLONASS       
	//system("aplay -Dhw:1 ../audio/ru_ecall.wav -fS16_LE -c 1");
#else
	//system("aplay -Dhw:1 ../audio/en_ecall.wav -fS16_LE -c 1");
#endif

}


extern void setGnssSystem(gnss_e gnss) {
	// Set the primary GNSS positioning system.
	// It can be either GPS or GLONASS.
}


extern void setLanguage(languages_e language) {
	// Set the language to be used for the prompts
}
