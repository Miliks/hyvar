#include <stdio.h>
#include "asn1.h"
#include "vehiclepropulsionstoragetype.h"

void init_vehiclepropulsionstoragetype(VehiclePropulsionStorageType_t *message) {
	message->gasolineTankPresent 	= ASN_FALSE;
	message->dieselTankPresent		= ASN_FALSE;
	message->compressedNaturalGas	= ASN_FALSE;
	message->liquidPropaneGas		= ASN_FALSE;
	message->electricEnergyStorage	= ASN_FALSE;
	message->hydrogenStorage		= ASN_FALSE;

	return;
}

/**
 * Encode the vehicle propulsion type. This procedure does not take
 * to account the extension, it encodes only the values in the root
 * @param message the Vehicle propulsion storage type structure
 * @param buffer the buffer where to store the encoding
 * @return the number of bits written, -1 in case of error
 * @see VehiclePropulsionStorageType_t
 */
asnint encode_vehiclepropulsionstoragetype(VehiclePropulsionStorageType_t *message, asn1msd_t *buffer) {
	asnint r = 0;

	if (NULL == message) return -1;

	// Add the extension bit, only root values are supported
	r+= addExtensionBit(EXTENSION_IN_ROOT, buffer);

	// Builds the preamble since all values have defaults
	// They are all bool, so the setBit can be called directly
	r+= setBit(message->gasolineTankPresent, 	buffer);
	r+= setBit(message->dieselTankPresent, 		buffer);
	r+= setBit(message->compressedNaturalGas, 	buffer);
	r+= setBit(message->liquidPropaneGas,		buffer);
	r+= setBit(message->electricEnergyStorage,  buffer);
	r+= setBit(message->hydrogenStorage, 		buffer);

	if (ASN_TRUE == message->gasolineTankPresent)
		r+= setBit(ASN_TRUE, buffer);

	if (ASN_TRUE == message->dieselTankPresent)
		r+= setBit(ASN_TRUE, buffer);

	if (ASN_TRUE == message->compressedNaturalGas)
		r+= setBit(ASN_TRUE, buffer);

	if (ASN_TRUE == message->liquidPropaneGas)
		r+= setBit(ASN_TRUE, buffer);

	if (ASN_TRUE == message->electricEnergyStorage)
		r+= setBit(ASN_TRUE, buffer);

	if (ASN_TRUE == message->hydrogenStorage)
		r+= setBit(ASN_TRUE, buffer);

	return r;
}

/**
 * Decodes the vehicle propulsion type. This method is not implemented.
 */
asnint decode_vehiclepropulsionstoragetype(VehiclePropulsionStorageType_t *message, asn1msd_t *buffer) {
	asnint r = -1;

	return r;
}
