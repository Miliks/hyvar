#include <stdio.h>
#include "asn1.h"
#include "controltype.h"

/**
 * Initializes the control type with default values
 */
void init_controltype(ControlType_t *message) {
	message->automaticActivation = ASN_TRUE;
	message->testCall			 = ASN_FALSE;
	message->positionCanBeTrusted= ASN_TRUE;
	init_vehicletype(&message->vehicleType);

	return;
}

/**
 * Encodes the control type:
   ControlType ::= SEQUENCE {
	automaticActivation BOOLEAN,
	testCall BOOLEAN,
	positionCanBeTrusted BOOLEAN,
	vehicleType VehicleType
  }
*/
asnint encode_controltype(ControlType_t *message, asn1msd_t *buffer) {
	asnint r = 0;
	
	r+= setBit(message->automaticActivation, buffer);
	r+= setBit(message->testCall, buffer);
	r+= setBit(message->positionCanBeTrusted, buffer);
	r+= encode_vehicletype(&message->vehicleType, buffer);

	return r;
}

/**
 * Decoding is not implemented
 */
asnint decode_controltype(ControlType_t *message, asn1msd_t *buffer) {
	asnint r = 0;

	r+= getBit(&message->automaticActivation, buffer);
	r+= getBit(&message->testCall, buffer);
	r+= getBit(&message->positionCanBeTrusted, buffer);
	r+= decode_vehicletype(&message->vehicleType, buffer);

	return r;
}
