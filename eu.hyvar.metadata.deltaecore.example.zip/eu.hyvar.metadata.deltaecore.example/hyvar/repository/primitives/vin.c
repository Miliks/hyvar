#include <stdio.h>
#include "asn1.h"
#include "vin.h"

static char vin_pattern[] = "0123456789ABCDEFGHJKLMNPRSTUVWXYZ";
#define VIN_PATTERN_LENGTH 33

static char 	isowmi[] 		= "WM9";
static char		isovds[]		= "VDSVDS";
static char		isovisModelYear[] = "Y";
static char		isovisSeqPlant[]  = "A123456";

/* 
VIN ::= SEQUENCE {
	isowmi PrintableString (SIZE(3))
		(FROM("A".."H"|"J".."N"|"P"|"R".."Z"|"0".."9")),
	isovds PrintableString (SIZE(6))
		(FROM("A".."H"|"J".."N"|"P"|"R".."Z"|"0".."9")),
	isovisModelyear PrintableString (SIZE(1))
		(FROM("A".."H"|"J".."N"|"P"|"R".."Z"|"0".."9")),
	isovisSeqPlant PrintableString (SIZE(7))
		(FROM("A".."H"|"J".."N"|"P"|"R".."Z"|"0".."9"))
}
*/

/**
 * Initializes the VIN with a default string which is
 * compliant with the encoding rules
 * @param message the VIN structure
 */
void init_vin(VIN_t  *message) {

	message->isowmi  = isowmi;
	message->isovds  = isovds;
	message->isovisModelYear = isovisModelYear;
	message->isovisSeqPlant = isovisSeqPlant;

	return;
}

/**
 * This function encodes a VIN.
 * @param message the structure
 * @param buffer the buffer where the encoded data will be saved
 * @return the number of encoded bits
 * @see asn1msd_t
 * @see VIN_t
 */
asnint encode_vin(VIN_t *message, asn1msd_t *buffer) {
	asnint r = 0;

	if (NULL == message) return -1;

	r+= encodePrintableStringWithPattern(vin_pattern,
										 VIN_PATTERN_LENGTH,
										 message->isowmi,
										 VIN_ISOWMI_LENGTH,
										 buffer);

	r+= encodePrintableStringWithPattern(vin_pattern,
											 VIN_PATTERN_LENGTH,
											 message->isovds,
											 VIN_ISOVDS_LENGTH,
											 buffer);

	r+= encodePrintableStringWithPattern(vin_pattern,
											 VIN_PATTERN_LENGTH,
											 message->isovisModelYear,
											 VIN_ISOVISMODELYEAR_LENGTH,
											 buffer);

	r+= encodePrintableStringWithPattern(vin_pattern,
											 VIN_PATTERN_LENGTH,
											 message->isovisSeqPlant,
											 VIN_ISOVISSEQPLANT_LENGTH,
											 buffer);

	return r;
}

/**
 * This function decodes a VIN. The decoding is not implemented.
 * @param message the structure
 * @param buffer the buffer containing the data to be decoded
 * @return the number of decoded bits
 * @see asn1msd_t
 * @see VIN_t
 */
asnint decode_vin(VIN_t *message, asn1msd_t *buffer) {
	asnint r = -1;

	return r;
}


