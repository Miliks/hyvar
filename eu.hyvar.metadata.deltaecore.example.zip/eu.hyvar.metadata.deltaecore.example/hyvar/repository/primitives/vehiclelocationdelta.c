#include <stdio.h>
#include "asn1.h"
#include "vehiclelocationdelta.h"

void init_vehiclelocationdelta(VehicleLocationDelta_t *message) {
	message->latitudeDelta = MIN_LATITUDEDELTA;
	message->longitudeDelta= MIN_LONGITUDEDELTA;

	return;
}

/**
 * Encode the vehicle propulsion type. This procedure does not take
 * to account the extension, it encodes only the values in the root
 * @param message the Vehicle propulsion storage type structure
 * @param buffer the buffer where to store the encoding
 * @return the number of bits written, -1 in case of error
 * @see VehiclePropulsionStorageType_t
 */
asnint encode_vehiclelocationdelta(VehicleLocationDelta_t *message, asn1msd_t *buffer) {
	asnint r = 0;

	if (NULL == message) return -1;

	// Add the extension bit, only root values are supported
	r+= encode_constrained_whole_number(message->latitudeDelta,
										MIN_LATITUDEDELTA,
										MAX_LATITUDEDELTA,
										buffer);

	r+= encode_constrained_whole_number(message->longitudeDelta,
										MIN_LONGITUDEDELTA,
										MAX_LONGITUDEDELTA,
										buffer);

	return r;
}

/**
 * Decodes the vehicle location delta type. This method is not implemented.
 */
asnint decode_vehiclelocationdelta(VehicleLocationDelta_t *message, asn1msd_t *buffer) {
	asnint r = -1;

	return r;
}
