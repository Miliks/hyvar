#include <stdio.h>

#if HAVE_CONFIG_H
# include <config.h>
#endif

#include "init_data.h"
#include "ATB2.h"

asnbool init_ecalldata(ECALLMessage_t *ecallMessage) {
	ecallMessage->msd.msdStructure.control.automaticActivation = ASN_TRUE;
	ecallMessage->msd.msdStructure.control.positionCanBeTrusted = ASN_TRUE;
	ecallMessage->msd.msdStructure.control.testCall = ASN_FALSE;

	ecallMessage->msd.msdStructure.control.vehicleType = getATB2VehicleType();

	// The VIN is already set in the default

	ecallMessage->msd.msdStructure.vehiclePropulsionStorageType.gasolineTankPresent = ASN_TRUE;
	ecallMessage->msd.msdStructure.vehiclePropulsionStorageType.electricEnergyStorage = ASN_TRUE;

	ecallMessage->msd.msdStructure.timestamp = getATB2Timestamp();

	ecallMessage->msd.msdStructure.vehicleLocation.positionLatitude = getATB2PositionLatitude();
	ecallMessage->msd.msdStructure.vehicleLocation.positionLongitude = getATB2PositionLongitude();

	ecallMessage->msd.msdStructure.vehicleDirection = getATB2VehicleDirection();

	// This is not needed since it's already initialized this way. Just put here
	// to remember how to set the optional data presence
	ecallMessage->msd.msdStructure.recentVehicleLocationN1Present = getATBRecentVehicleLocationN1Present();
	ecallMessage->msd.msdStructure.recentVehicleLocationN1.latitudeDelta = getATBRecentVehicleLocationN1latitudeDelta();
	ecallMessage->msd.msdStructure.recentVehicleLocationN1.longitudeDelta = getATBRecentVehicleLocationN1longitudeDelta();

	ecallMessage->msd.msdStructure.recentVehicleLocationN2Present = getATBRecentVehicleLocationN2Present();
	ecallMessage->msd.msdStructure.recentVehicleLocationN2.latitudeDelta = getATBRecentVehicleLocationN2latitudeDelta();
	ecallMessage->msd.msdStructure.recentVehicleLocationN2.longitudeDelta = getATBRecentVehicleLocationN2longitudeDelta();

	ecallMessage->msd.msdStructure.numberOfPassengersPresent = OPTION_PRESENT;
	ecallMessage->msd.msdStructure.numberOfPassengers = getATB2NumberOfPassengers();

	return ASN_TRUE;
}


asnint init_eraGlonassData(ECALLMessage_t *ecallMessage) {

#if defined(ERAGLONASS)
	ecallMessage->msd.optionalAdditionalDataPresent = OPTION_PRESENT; 

	ecallMessage->msd.optionalAdditionalData.severecrashestimation = ASN_FALSE;

	ecallMessage->msd.optionalAdditionalData.MobileDefPresence = OPTION_PRESENT;
	ecallMessage->msd.optionalAdditionalData.mobiledef.eramcc = (asnlong)getMCC();
	ecallMessage->msd.optionalAdditionalData.mobiledef.erassi = (asnlong)getRSSI();

	ecallMessage->msd.optionalAdditionalData.TestResultsDefPresence = OPTION_PRESENT;

	getAutoDiagResults(&ecallMessage->msd.optionalAdditionalData.testresultdef);
	/*
	ecallMessage->msd.optionalAdditionalData.testresultdef.gnssantennafailure = isGNSSAntennaFaultPresent();
	ecallMessage->msd.optionalAdditionalData.testresultdef.rightspeakerfailure = isSpeakerFaultPresent;
	*/

	ecallMessage->msd.optionalAdditionalData.CrashDefPresence = OPTION_PRESENT;
	ecallMessage->msd.optionalAdditionalData.crashdef.crashfront = ASN_TRUE;
#endif

	return ASN_TRUE;
}

