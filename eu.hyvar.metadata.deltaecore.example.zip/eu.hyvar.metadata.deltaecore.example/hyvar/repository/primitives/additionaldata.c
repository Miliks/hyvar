#include "stdio.h"
#include "asn1.h"
#include "additionaldata.h"



asnbit ID_ADDITIONALDATA[] = { 0, 0, 0, 0, 0, 0, 0, 1 };
asnbit OID_ADDITIONALDATA[] = { 1, 0, 0, 0, 0, 0, 0, 0 };

/**
 * Encoding and decoding of additional data is not supported
 */

void init_additionaldata(AdditionalData_t *message) {
	asnint i = 0;

	message->MobileDefPresence = OPTION_NOT_PRESENT;
	message->TestResultsDefPresence = OPTION_NOT_PRESENT;
	message->CrashDefPresence = OPTION_NOT_PRESENT;

	message->severecrashestimation = ASN_FALSE;

	for (i = 0; i < (asnint)OID_ADDITIONAL_DATA_LENTH; i++, message->oid[i] = OID_ADDITIONALDATA[i]);
	for (i = 0; i < (asnint)ID_ADDITIONAL_DATA_LENTH; i++, message->id[i] = ID_ADDITIONALDATA[i]);

	init_mobiledef(&message->mobiledef);
	init_testresultdef(&message->testresultdef);
	init_crashdef(&message->crashdef);

	return;
}

asnint encode_additionaldata(AdditionalData_t *message, asn1msd_t *buffer) {
	asnint r = 0;

	if (NULL == message) return -1;

	// Encodes the mask of the optional fields
	r += addOptionalBit(message->MobileDefPresence, buffer);
	r += addOptionalBit(message->TestResultsDefPresence, buffer);
	r += addOptionalBit(message->CrashDefPresence, buffer);

	// Encode the mandatory fields
	r += encodeBitString(message->oid, (asnint)OID_ADDITIONAL_DATA_LENTH, buffer);
	r += encodeBitString(message->id, (asnint)ID_ADDITIONAL_DATA_LENTH, buffer);
	r += encode_boolean(message->severecrashestimation, buffer);


	// Optional fields are NULL by default
	if (OPTION_PRESENT == message->MobileDefPresence)
		r += encode_mobiledef(&message->mobiledef, buffer);

	if (OPTION_PRESENT == message->TestResultsDefPresence)
		r += encode_testresultdef(&message->testresultdef, buffer);

	if (OPTION_PRESENT == message->CrashDefPresence)
		r += encode_crashdef(&message->crashdef, buffer);

	return r;
}

asnint decode_additionaldata(AdditionalData_t *message, asn1msd_t *buffer) {
	return -1;
}
