/* --- The following code comes from C:\lcc\lib\wizard\textmode.tpl. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "asn1.h"
#include "ecallmessage.h"

asnllong IntTwoComplement(asnllong x) {

	return (~x + 1);
}

/*
 * ASN.1:1984 (X.409)
 */
#define MAX_PRINTABLESTRING_CHARS  256
static char _PrintableString_alphabet[MAX_PRINTABLESTRING_CHARS] = {
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,	/*                  */
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,	/*                  */
 1, 0, 0, 0, 0, 0, 0, 2, 3, 4, 0, 5, 6, 7, 8, 9,	/* .      '() +,-./ */
10,11,12,13,14,15,16,17,18,19,20, 0, 0,21, 0,22,	/* 0123456789:  = ? */
 0,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,	/*  ABCDEFGHIJKLMNO */
38,39,40,41,42,43,44,45,46,47,48, 0, 0, 0, 0, 0,	/* PQRSTUVWXYZ      */
 0,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,	/*  abcdefghijklmno */
64,65,66,67,68,69,70,71,72,73,74, 0, 0, 0, 0, 0,	/* pqrstuvwxyz      */
};

/*****************************************************************/
/* Static functions                                              */
/*****************************************************************/
static asnint find_printablechar_in_pattern(char c, char *pattern, asnint patternlength);


/**
 * This function returns the index (0 based) within the passed pattern, of the char
 * which must be represented.
 * This function does not check whether the passed char is actually a printable char
 * or not.
 * @param c the printable char to be represented
 * @param pattern the pattern of possible printable chars
 * @param patternlength the length of the patterns, in number of chars
 * @return the index (0-based) of the char in the pattern, -1 if the char is not found
 */
static asnint find_printablechar_in_pattern(char c, char *pattern, asnint patternlength) {
	asnint r = 0;

	if (NULL == pattern) return -1;
	if (0 == patternlength) return -1;

	while (r < patternlength && pattern[r] != c) {
		r++;
	}

	// Not found
	if (r >= patternlength) r = -1;

	return r;
}

/*****************************************************************/
/* ASN.1 Basic Types encoding routines                           */
/*****************************************************************/
asnint findMinBits(asnllong number) {
 	asnint i = 0;
	asnllong mask = (asnllong)1;

	if (0 > number)
		number = IntTwoComplement(number);
/*
	while (number > 0) {
		i++;
		number = number / 2;
	}
*/
	while (mask < number) {
		i++;
		mask = mask << 1;
	}

	return i;
}


asnint setBit(asnbool flag, asn1msd_t *buffer) {
	asnint bytto	= 0;
	asnint bitto	= 0;

	if (NULL == buffer) return -1;

	bytto	= (int)(buffer->bitno / 8);
	bitto	= (int)(7 - (buffer->bitno % 8));

	// Takes the bit from the input buffer and copies it to the destination
	if (flag)
			buffer->msd[bytto] |= (char)(0x1 << bitto);
		else
			buffer->msd[bytto] &= (char)(~(0x1 << bitto));

	buffer->bitno++;

	return 1;
}

/**
 * Get one bit from the buffer.
 * @param bit the pointer to the bit
 * @param buffer the buffer containing the bit to be encoded
 * @return 1 if everything is fine, 0 otherwise
 */
asnint getBit(asnbool *bit, asn1msd_t *buffer) {
	asnint bytto	= 0;
	asnint bitto	= 0;

	if (NULL == buffer) return -1;

	bytto	= (int)(buffer->bitno / 8);
	bitto	= (int)(7 - (buffer->bitno % 8));

	// Takes the bit from the input buffer and copies it to the destination
	*bit = buffer->msd[bytto] &= (char)(0x1 << bitto);
	*bit = (0 != *bit)?1:0;
	
	// Advance in the buffer
	buffer->bitno++;

	return 1;
}

asnint setBits(asnint bits, asnllong number, asn1msd_t *buffer) {
	asnint		i	 = 0;
    asnllong bitmask = 0x00;

	for (i = 0; i < bits; i++) {
		bitmask = (asnllong)(0x01 << (bits - i - 1));
		setBit(((number & bitmask)?ASN_TRUE:ASN_FALSE), buffer);
	}
	return bits;
}

/**
 * Get the number of bits, at most siseof(asnllong) from the specified buffer.
 * @param bits the number of bits to be taken from the buffer
 * @param number the resulting bits
 * @param buffer the buffer containing the asn.1 per unaligned string
 * @return the number of bits read, -1 in case of error
 */
asnint getBits(asnint bits, asnllong *number, asn1msd_t *buffer) {
	asnint    r		= 0;
	asnint    i		= 0;
	asnbool   bit	= 0;
	asnllong  no	= 0;

	for (i = 0; i < bits; i++) {
		if (0 > (bit = getBit(&bit, buffer))) return -1;
		no <<=1;
		no +=(asnllong)bit;
	}

	*number = no;
	
	return r;
}


asnint addBits(char *frombits, asn1msd_t *buffer, asnint bitno) {
	asnint i	= 0;
	asnint bytfrom = 0;
	asnint bitfrom = 0;
	unsigned char tmp;

	if (NULL == buffer) return -1;

	for (i = 0; i < bitno; i++) {
		bytfrom = (int)(i / 8);
		bitfrom = (int)(i % 8);

		// Takes the bit from the input buffer and copies it to the destination
		tmp = (unsigned char)(frombits[bytfrom] & (char)(0x1 << bitfrom));
		setBit((0 == tmp), buffer);
	}

	return i;
}

asnint encode_boolean(asnbool value, asn1msd_t *buffer) {
	asnint r = 0;

	r = setBit(value, buffer);
	return r;
}

asnint decode_boolean(asnbool *value, asn1msd_t *buffer) {
	asnint r = 0;

	r = getBit(value, buffer);

	return r;
}

asnint encode_constrained_whole_number(asnllong number, asnllong lowerbound, asnllong upperbound, asn1msd_t *buffer) {
	asnint bits 	= 0;
	asnllong range 	= 0;
	asnint i		= 0;

	// Some consistency checks to avoid to encode an inconsistent range
	if (upperbound < lowerbound) return -1;
	if (number < lowerbound || number > upperbound) return -1;

	// Range must require at least one bit.
	if (1 >= (upperbound - lowerbound)) return 0;

	// Let's evaluate how many bits are needed to encode the range
	range = upperbound - lowerbound + 1; // Cfr. 10.5.3

	bits = findMinBits(range);

	// Transforms the number into a positive number starting from the lowerbound
	// and gets the resulting bits
	i = setBits(bits, number - lowerbound , buffer);

	return i;
}

asnint decode_constrained_whole_number(asnllong *number, asnllong lowerbound, asnllong upperbound, asn1msd_t *buffer) {
	asnint bits 	= 0;
	asnllong range 	= 0;
	asnint i		= 0;

	// Some consistency checks to avoid to encode an inconsistent range
	if (upperbound < lowerbound) return -1;

	// Range must require at least one bit.
	if (1 >= (upperbound - lowerbound)) return 0;

	// Let's evaluate how many bits are needed to encode the range
	range = upperbound - lowerbound + 1; // Cfr. 10.5.3

	bits = findMinBits(range);

	// Transforms the number into a positive number starting from the lowerbound
	// and gets the resulting bits
	i = getBits(bits, number, buffer);
	*number += lowerbound;

	return i;
}

/**
 * Cfr. 10.6 normally small non-negative whole number
 * This procedure is used when encoding a non-negative whole number that is expected to be small, but whose
 * size is potentially unlimited due to the presence of an extension marker. An example is a choice index
 * @param number the integer to represent
 * @buffer the buffer where data are stored
 * @see asn1msd_t
 */
asnint encode_normally_small_non_negative_whole_number(asnllong number, asn1msd_t *buffer) {
	asnint i = 0;
	asnint bits = 6;
	asnllong tmp  = 0;

	if (63 >= number) { // cfr. 10.6.1
		i = setBit(0, buffer); 	// 1-bit bitfied sed to 0
		i+= setBits(6, number, buffer);
	}
	else {
		// Find out the number of bits to encode the number
		tmp = number;
		bits = 0;
		while ((tmp = (tmp >> 1)) > 0) bits++;

	 	i+= setBit(1, buffer);  // Cfr. 10.6.2
	    i+= encode_length_determinant(bits, buffer);
		i+= encode_semi_constrained_whole_number(number, 0, buffer);
	}
	return i;
}

// Cfr. 10.7 Encoding of a semi-constrained whole number
asnint encode_semi_constrained_whole_number(asnllong number, asnllong lowerbound, asn1msd_t *buffer) {
	asnint bits = 0;

	// Let's use a trick. The semi constrained whole number can be thought as a
	// constrained whole number where the upperbound of the range is exactly the
	// number
	bits = encode_constrained_whole_number(number, number, lowerbound, buffer);

	return bits;
}

// Cfr 10.8 Encoding of an unconstrained whole number
asnint encode_unconstrained_whole_number(asnllong number, asn1msd_t *buffer) {
	asnint bits = 0;

	// Finds the minimum number of bits used to represent the integer
	// add one bit for the sign
	bits = findMinBits(number) + 1;

	// Encode the length determinant in terms of octets needed
	encode_length_determinant((bits/8) + ((bits%8)?1:0), buffer);
	bits = setBits(bits, number, buffer);

	return bits;
}

asnint encode_length_determinant(asnint lenght, asn1msd_t *buffer) {
	return 0;
}

// Cfr. 10.9.4
asnint encode_length_determinant_less_64K(asnint length, asnint lowerbound, asnint upperbound, asn1msd_t *buffer) {
	asnint bits = 0;

	if (65536 > length) { // Cfr. 10.9.4.1
		bits = encode_constrained_whole_number(length, lowerbound, upperbound, buffer);
	}
	else {   // Cfr. 10.9.4.2 not supported: Length > 64K
		bits = -1;
	}

	return bits;
}

/**********************************************************************/
/*                 ASN.1 SPECIFIC LANGUAGE CODINGS                    */
/**********************************************************************/

/**
 * Adds an extension bit. This procedure is called when an extension is
 * used...
 */
asnint addExtensionBit(asnint is_in_root, asn1msd_t *buffer) {
	asnint r = 0;

	r = setBit((is_in_root)?0:1, buffer);

	return r;
}

/**
 * get the extension bit. This procedure is called when an extension is
 * used...
 */
asnint getExtensionBit(asnint *is_in_root, asn1msd_t *buffer) {
	asnint r = 0;

	r = getBit(is_in_root, buffer);

	*is_in_root = ((1 == *is_in_root)?EXTENSION_NOT_IN_ROOT:EXTENSION_IN_ROOT);

	return r;
}

/**
 * Adds an option bit.
 */
asnint addOptionalBit(asnint presence, asn1msd_t *buffer) {
	asnint r = 0;

	r = setBit((presence)?OPTION_PRESENT:OPTION_NOT_PRESENT, buffer);
	return r;
}

/**
 * Checks the presence of an optional field. In case the field is present, the
 * corresponding passed parameter will assume the value OPTION_PRESENT. If it
 * is not present, it will assume the OPTION_NOT_PRESENT value
 * @param presence the variable where the presence field is stored. This variable
 * will assume the value OPTION_PRESENT or OPTION_NOT_PRESENT
 * @param buffer the buffer containing the string to be decoded
 * @return -1 in case of error, >=0 otherwise
 */
asnint getOptionalBit(asnint *presence, asn1msd_t *buffer) {
	asnint r = 0;

	r = getBit(presence, buffer);

	return r;
}

/**
 * Adds an enumeration type. This procedure does not handle the extension fields
 * when the value is out of the root values (to be implemented).
 * @param value the value to be encoded
 * @param lowerbound the lowerbound of the root values
 * @param upperbound the upperbound of the root values
 * @param isinroot whether the value is among the root values (probably this is redundant)
 * @praram buffer the buffer where to store the data
 */
asnint encodeEnumeration(asnllong value, asnllong lowerbound, asnllong upperbound, asnbool isinroot, asn1msd_t *buffer) {
	asnint r = 0;

	// Extension is not supported
	if (ASN_FALSE == isinroot) return -1;

	r = encode_constrained_whole_number(value, lowerbound, upperbound, buffer);
	
	return r;
}

/**
 * Decodes an enumeration type. This procedure does not handle the extension fields
 * when the value is out of the root values (to be implemented).
 * @param value the variable where the decoded value is stored 
 * @param lowerbound the lowerbound of the root values
 * @param upperbound the upperbound of the root values
 * @param isinroot whether the value is among the root values (probably this is redundant)
 * @praram buffer the buffer containing the asn.1 per unaligned string to be decoded
 */
asnint decodeEnumeration(asnllong *value, asnllong lowerbound, asnllong upperbound, asnbool isinroot, asn1msd_t *buffer) {
	asnint r = 0;

	// Extension is not supported
	if (ASN_FALSE == isinroot) return -1;

	r = decode_constrained_whole_number(value, lowerbound, upperbound, buffer);
	
	return r;
}

/**
 * Encodes a printable string given the passed pattern.
 * A limitation of this function is that it does not check that the passed string
 * contains printable chars.
 * @param pattern the pattern of chars
 * @param patternlength the lenght of the pattern, in number of chars
 * @param the printable string to encode
 */
asnint encodePrintableStringWithPattern(char *pattern, asnint patternlength, char *string, asnint strlength, asn1msd_t *buffer) {
	asnint r = 0;
	asnint i = 0;
	asnint p = 0;

	// if there's no pattern, it is assumed that the whole printable char space is used
	if (NULL == pattern) {
		pattern			= _PrintableString_alphabet;
		patternlength	= MAX_PRINTABLESTRING_CHARS;
	}
	// Nothing to encode...
	if (1 == patternlength) return 0;

	// Consistency check
	if (NULL == string || 0 > strlength) return -1;

	for (i = 0; i < strlength; i++) {
		// Stops the for statement if the letter is not in the pattern
		p = find_printablechar_in_pattern(string[i], pattern, patternlength);
		if (0 > p) { r = -1; break; }
		r+= encode_constrained_whole_number((asnllong)p, 0L, (asnllong)(patternlength - 1), buffer);
	}

	return r;
}

asnint encodeBitString(asnbit* value, asnint length, asn1msd_t *buffer) {
	asnint r = 0;
	asnint i = 0;
	
	// If there's no bitstring, then it encodes nothing
	if (NULL != value) {
		for (i = 0; i < length; i++) {
			r += setBit((asnbool)value[i], buffer);
		}
	}

	return r;

}
