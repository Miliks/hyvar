#include "stdio.h"
#include "asn1.h"
#include "msdmessage.h"

#if HAVE_CONFIG_H
# include <config.h>
#endif

#if defined(ERAGLONASS)
static asnint encode_optionaldata(MSDMessage_t *message, asn1msd_t *buffer);
#endif

/**
 * Initializes the MSDMessage with default data
 */
void init_msdmessage(MSDMessage_t *message) {
	message->optionalAdditionalDataPresent = OPTION_NOT_PRESENT;
	init_msdstructure(&(message->msdStructure));

	return;
}

/** 
 * encodes an msd message from the asn1 notation.
 * MSDMessage ::= SEQUENCE {
	msdStructure MSDStructure,
	optionalAdditionalData AdditionalData OPTIONAL,
	...
  }
 */
asnint encode_msdmessage(MSDMessage_t *message, asn1msd_t *buffer) {
	asnint r = 0;

	if (NULL == message) return -1;

	// First adds an extension bit, we're in root
	r = addExtensionBit(EXTENSION_IN_ROOT, buffer);

	// if there's the optional data, we need to add the bitmask
	r+= addOptionalBit( ((OPTION_PRESENT == message->optionalAdditionalDataPresent)?OPTION_PRESENT:OPTION_NOT_PRESENT), buffer);

	// Let's encode the msdstructure
	r+= encode_msdstructure(&message->msdStructure, buffer);

	return r;
}

#if defined(ERAGLONASS)
static asnint encode_optionaldata(MSDMessage_t *message, asn1msd_t *buffer) {
	asnint r = 0;

	if (ASN_TRUE == message->optionalAdditionalDataPresent)
		r+= encode_additionaldata(&message->optionalAdditionalData, buffer);

	return r;
}
#endif

/**
 * Decodes and MSD message structure. It does not handle the case where the value is
 * not among the root values.
 */
asnint decode_msdmessage(MSDMessage_t *message, asn1msd_t *buffer) {
	asnint r = 0;
	asnint is_in_root = EXTENSION_IN_ROOT;

	if (NULL == message) return -1;

	// First adds an extension bit, we're in root
	r = getExtensionBit(&is_in_root, buffer);
	if (0 > r || EXTENSION_IN_ROOT == is_in_root) return -1;

	// if there's the optional data, we need to get the bitmask
	r+= getOptionalBit( &message->optionalAdditionalDataPresent, buffer);

	// Let's encode the msdstructure
	r+= decode_msdstructure(&message->msdStructure, buffer);

#if defined(ERAGLONASS)
	if (OPTION_PRESENT == message->optionalAdditionalDataPresent)
		r+= encode_additionaldata(&message->optionalAdditionalData, buffer);
#endif

	return r;
}
