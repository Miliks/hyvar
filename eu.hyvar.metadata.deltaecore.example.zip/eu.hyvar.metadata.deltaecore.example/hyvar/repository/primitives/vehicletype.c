#include <stdio.h>
#include "asn1.h"
#include "vehicletype.h"

/* 
 * ASN.1
	VehicleType ::= ENUMERATED{
		passengerVehicleClassM1 (1),
		busesAndCoachesClassM2 (2),
		busesAndCoachesClassM3 (3),
		lightCommercialVehiclesClassN1 (4),
		heavyDutyVehiclesClassN2 (5),
		heavyDutyVehiclesClassN3 (6),
		motorcyclesClassL1e (7),
		motorcyclesClassL2e (8),
		motorcyclesClassL3e (9),
		motorcyclesClassL4e (10),
		motorcyclesClassL5e (11),
		motorcyclesClassL6e (12),
		motorcyclesClassL7e (13),
		...
	}
*/

/**
 * Default initialization: it assumes we're on a car. Vehicle class M1
 */
void init_vehicletype(VehicleType_t  *message) {
	*message = VehicleType_passengerVehicleClassM1;

	return;
}

/**
 * Encodes the Vehicle type. This function only supports the case where
 * the vehicle type is inside the root values and it's not extended
 */
asnint encode_vehicletype(VehicleType_t *message, asn1msd_t *buffer) {
	asnint r = 0;
	
	if (*message > MAX_VEHICLETYPE_RANGE)
		return -1;

	// Set the extension bit
	r+= addExtensionBit(((MAX_VEHICLETYPE_RANGE >= *message)?EXTENSION_IN_ROOT:EXTENSION_NOT_IN_ROOT), buffer);
	r+= encodeEnumeration(*message, MIN_VEHICLETYPE_RANGE, MAX_VEHICLETYPE_RANGE, ASN_TRUE, buffer);
	
	return r;
}

/** 
 * Not implemented
 */
asnint decode_vehicletype(VehicleType_t *message, asn1msd_t *buffer) {
	asnint r = -1;

	return r;
}
