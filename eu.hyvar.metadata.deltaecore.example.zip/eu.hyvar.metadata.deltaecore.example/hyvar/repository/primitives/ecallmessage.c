/** 
 * This file contains the service routines to encode and decode (future)
 * and ecall message
 */

#include "asn1.h"
#include "ecallmessage.h"

/** 
 * Initialize the eCall with default parameters
 */
void init_ecallmessage(ECALLMessage_t *message) {
	message->id = 1;
	init_msdmessage(&(message->msd));

	return;
}

/**
 * Performs the encoding of the ecall message
 * ASN.1
 * ECallMessage ::= SEQUENCE {
 *		id INTEGER(0 .. 255),
 *		msd MSDMessage
 * }
 */
asnint encode_ecallmessage(ECALLMessage_t *message, asn1msd_t *buffer) {
	asnint r = 0;
	
	r = encode_constrained_whole_number(message->id, 0, 255, buffer);
	r+= encode_msdmessage(&(message->msd), buffer);

	return r;
}

/**
 * Not yet implemented
 */
asnint decode_ecallmessage(ECALLMessage_t *message, asn1msd_t *buffer) {
	asnint r = 0;
	
	r = decode_constrained_whole_number(&message->id, 0, 255, buffer);
	r+= decode_msdmessage(&(message->msd), buffer);

	return r;
}
