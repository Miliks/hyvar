#include <stdio.h>
#include "asn1.h"
#include "testresultdef.h"

/**
* Initializes the TestResultDef with default values
*/
void init_testresultdef(TestResultDef_t *message) {
	message->micconnectionfailure = ASN_FALSE;
	message->micfailure = ASN_FALSE;
	message->rightspeakerfailure = ASN_FALSE;
	message->leftspeakerfailure = ASN_FALSE;
	message->speakersfailure = ASN_FALSE;
	message->ignitionlinefailure = ASN_FALSE;
	message->uimfailure = ASN_FALSE;
	message->statusindicatorfailure = ASN_FALSE;
	message->batteryfailure = ASN_FALSE;
	message->batteryvoltagelow = ASN_FALSE;
	message->crashsensorfailure = ASN_FALSE;
	message->swimagecorruption = ASN_FALSE;
	message->commmoduleinterfacefailure = ASN_FALSE;
	message->gnssreceiverfailure = ASN_FALSE;
	message->raimproblem = ASN_FALSE;
	message->gnssantennafailure = ASN_FALSE;
	message->commmodulefailure = ASN_FALSE;
	message->eventsmemoryoverflow = ASN_FALSE;
	message->crashprofilememoryoverflow = ASN_FALSE;
	message->othercriticalfailures = ASN_FALSE;
	message->othernotcriticalfailures = ASN_FALSE;

	return;
}

/**
* Encodes the testresultdef
*/
asnint encode_testresultdef(TestResultDef_t *message, asn1msd_t *buffer) {
	asnint r = 0;

	/** Header */
	r += setBit(message->micconnectionfailure, buffer);
	r += setBit(message->micfailure, buffer);
	r += setBit(message->rightspeakerfailure, buffer);
	r += setBit(message->leftspeakerfailure, buffer);
	r += setBit(message->speakersfailure, buffer);
	r += setBit(message->ignitionlinefailure, buffer);
	r += setBit(message->uimfailure, buffer);
	r += setBit(message->statusindicatorfailure, buffer);
	r += setBit(message->batteryfailure, buffer);
	r += setBit(message->batteryvoltagelow, buffer);
	r += setBit(message->crashsensorfailure, buffer);
	r += setBit(message->swimagecorruption, buffer);
	r += setBit(message->commmoduleinterfacefailure, buffer);
	r += setBit(message->gnssreceiverfailure, buffer);
	r += setBit(message->raimproblem, buffer);
	r += setBit(message->gnssantennafailure, buffer);
	r += setBit(message->commmodulefailure, buffer);
	r += setBit(message->eventsmemoryoverflow, buffer);
	r += setBit(message->crashprofilememoryoverflow, buffer);
	r += setBit(message->othercriticalfailures, buffer);
	r += setBit(message->othernotcriticalfailures, buffer);

	/* Actual Values */
	if (ASN_TRUE == message->micconnectionfailure)	r += setBit(message->micconnectionfailure, buffer);
	if (ASN_TRUE == message->micfailure)			r += setBit(message->micfailure, buffer);
	if (ASN_TRUE == message->rightspeakerfailure)	r += setBit(message->rightspeakerfailure, buffer);
	if (ASN_TRUE == message->leftspeakerfailure)	r += setBit(message->leftspeakerfailure, buffer);
	if (ASN_TRUE == message->speakersfailure)		r += setBit(message->speakersfailure, buffer);
	if (ASN_TRUE == message->ignitionlinefailure)	r += setBit(message->ignitionlinefailure, buffer);
	if (ASN_TRUE == message->uimfailure)			r += setBit(message->uimfailure, buffer);
	if (ASN_TRUE == message->statusindicatorfailure) r += setBit(message->statusindicatorfailure, buffer);
	if (ASN_TRUE == message->batteryfailure)		r += setBit(message->batteryfailure, buffer);
	if (ASN_TRUE == message->batteryvoltagelow)		r += setBit(message->batteryvoltagelow, buffer);
	if (ASN_TRUE == message->crashsensorfailure)	r += setBit(message->crashsensorfailure, buffer);
	if (ASN_TRUE == message->swimagecorruption)		r += setBit(message->swimagecorruption, buffer);
	if (ASN_TRUE == message->commmoduleinterfacefailure)	r += setBit(message->commmoduleinterfacefailure, buffer);
	if (ASN_TRUE == message->gnssreceiverfailure)	r += setBit(message->gnssreceiverfailure, buffer);
	if (ASN_TRUE == message->raimproblem)			r += setBit(message->raimproblem, buffer);
	if (ASN_TRUE == message->gnssantennafailure)	r += setBit(message->gnssantennafailure, buffer);
	if (ASN_TRUE == message->commmodulefailure)		r += setBit(message->commmodulefailure, buffer);
	if (ASN_TRUE == message->eventsmemoryoverflow)	r += setBit(message->eventsmemoryoverflow, buffer);
	if (ASN_TRUE == message->crashprofilememoryoverflow)	r += setBit(message->crashprofilememoryoverflow, buffer);
	if (ASN_TRUE == message->othercriticalfailures) r += setBit(message->othercriticalfailures, buffer);
	if (ASN_TRUE == message->othernotcriticalfailures) r += setBit(message->othernotcriticalfailures, buffer);

	return r;
}

/**
* Decoding is not implemented
*/
asnint decode_testresultdef(TestResultDef_t *message, asn1msd_t *buffer) {
	asnint r = 0;

	r += getBit(&message->micconnectionfailure, buffer);
	r += getBit(&message->micfailure, buffer);
	r += getBit(&message->rightspeakerfailure, buffer);
	r += getBit(&message->leftspeakerfailure, buffer);
	r += getBit(&message->speakersfailure, buffer);
	r += getBit(&message->ignitionlinefailure, buffer);
	r += getBit(&message->uimfailure, buffer);
	r += getBit(&message->statusindicatorfailure, buffer);
	r += getBit(&message->batteryfailure, buffer);
	r += getBit(&message->batteryvoltagelow, buffer);
	r += getBit(&message->crashsensorfailure, buffer);
	r += getBit(&message->swimagecorruption, buffer);
	r += getBit(&message->commmoduleinterfacefailure, buffer);
	r += getBit(&message->gnssreceiverfailure, buffer);
	r += getBit(&message->raimproblem, buffer);
	r += getBit(&message->gnssantennafailure, buffer);
	r += getBit(&message->commmodulefailure, buffer);
	r += getBit(&message->eventsmemoryoverflow, buffer);
	r += getBit(&message->crashprofilememoryoverflow, buffer);
	r += getBit(&message->othercriticalfailures, buffer);
	r += getBit(&message->othernotcriticalfailures, buffer);


	return r;
}
