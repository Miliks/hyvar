#include <stdio.h>
#include "asn1.h"
#include "vehiclelocation.h"

void init_vehiclelocation(VehicleLocation_t *message) {
	message->positionLatitude = MIN_POSITIONLATITUDE;
	message->positionLongitude= MIN_POSITIONLONGITUDE;

	return;
}

/**
 * Encode the vehicle propulsion type. This procedure does not take
 * to account the extension, it encodes only the values in the root
 * @param message the Vehicle propulsion storage type structure
 * @param buffer the buffer where to store the encoding
 * @return the number of bits written, -1 in case of error
 * @see VehiclePropulsionStorageType_t
 */
asnint encode_vehiclelocation(VehicleLocation_t *message, asn1msd_t *buffer) {
	asnint r = 0;

	if (NULL == message) return -1;

	// Add the extension bit, only root values are supported
	r+= encode_constrained_whole_number(message->positionLatitude,
										MIN_POSITIONLATITUDE,
										MAX_POSITIONLATITUDE,
										buffer);

	r+= encode_constrained_whole_number(message->positionLongitude,
			MIN_POSITIONLONGITUDE,
			MAX_POSITIONLONGITUDE,
			buffer);

	return r;
}

/**
 * Decodes the vehicle location type. This method is not implemented.
 */
asnint asnintdecode_vehiclelocation(VehicleLocation_t *message, asn1msd_t *buffer) {
	asnint r = -1;

	return r;
}
