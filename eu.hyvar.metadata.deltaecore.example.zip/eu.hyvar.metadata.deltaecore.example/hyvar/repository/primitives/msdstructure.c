#include <stdio.h>
#include "asn1.h"
#include "msdstructure.h"

void init_msdstructure(MSDStructure_t *message) {
	message->messageIdentifier = 0x01;
	init_controltype(&message->control);
	init_vin(&message->vehicleIdentificationNumber);
	init_vehiclepropulsionstoragetype(&message->vehiclePropulsionStorageType);	
	message->timestamp = 0LL;
	init_vehiclelocation(&message->vehicleLocation);
	message->vehicleDirection = 0LL;

	// Optional fields are NULL by default
	message->recentVehicleLocationN1Present = OPTION_NOT_PRESENT;
	init_vehiclelocationdelta(&message->recentVehicleLocationN1);
	
	message->recentVehicleLocationN2Present = OPTION_NOT_PRESENT;
	init_vehiclelocationdelta(&message->recentVehicleLocationN2);

	message->numberOfPassengersPresent = OPTION_NOT_PRESENT;
	message->numberOfPassengers		   = 0;

	return;
}

asnint encode_msdstructure(MSDStructure_t *message, asn1msd_t *buffer) {
	asnint r = 0;

	if (NULL == message) return -1;

	// First adds an extension bit, we're in root
	r = addExtensionBit(EXTENSION_IN_ROOT, buffer);

	// if there's the optional data, we need to add the bitmask
	r+= addOptionalBit( message->recentVehicleLocationN1Present, buffer);
	r+= addOptionalBit( message->recentVehicleLocationN2Present, buffer);
	r+= addOptionalBit( message->numberOfPassengersPresent, buffer);

	// Encode the data
	r+= encode_constrained_whole_number(message->messageIdentifier, 0, 255, buffer);
	r+= encode_controltype(&message->control, buffer);
	r+= encode_vin(&message->vehicleIdentificationNumber, buffer);
	r+= encode_vehiclepropulsionstoragetype(&message->vehiclePropulsionStorageType, buffer);	
	r+= encode_constrained_whole_number(message->timestamp, 0, 4294967295LL, buffer);
	r+= encode_vehiclelocation(&message->vehicleLocation, buffer);
	r+= encode_constrained_whole_number(message->vehicleDirection, 0, 255, buffer);

	// Optional fields are NULL by default
	if (OPTION_PRESENT == message->recentVehicleLocationN1Present)
		r+= encode_vehiclelocationdelta(&message->recentVehicleLocationN1, buffer);

	if (OPTION_PRESENT == message->recentVehicleLocationN2Present)
		r+= encode_vehiclelocationdelta(&message->recentVehicleLocationN2, buffer);

	if (OPTION_PRESENT == message->numberOfPassengersPresent)
		r+= encode_constrained_whole_number(message->numberOfPassengers, 0, 255, buffer);

	return r;
}

asnint decode_msdstructure(MSDStructure_t *message, asn1msd_t *buffer) {
	return -1;
}
