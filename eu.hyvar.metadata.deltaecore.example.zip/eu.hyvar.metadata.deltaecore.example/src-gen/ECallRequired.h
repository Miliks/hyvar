
#ifndef ECALLREQUIRED_H_
#define ECALLREQUIRED_H_

#include "..\src\sc_types.h"
#include "ECall.h"

#ifdef __cplusplus
extern "C"
{
#endif 

/*! \file This header defines prototypes for all functions that are required by the state machine implementation.

This state machine makes use of operations declared in the state machines interface or internal scopes. Thus the function prototypes:
	- eCallIfaceFunc_aTB2init
	- eCallIfaceFunc_init_ecallmessage
	- eCallIfaceFunc_init_additionaldata
	- eCallIfaceFunc_init_eraGlonass_data
	- eCallIfaceFunc_init_eCall_data
	- eCallIfaceFunc_setGnssSystem
	- eCallIfaceFunc_setLanguage
	- eCallIfaceFunc_encode_ecallmessage
	- eCallIfaceFunc_encode_optionaldata
	- eCallIfaceFunc_play_prompt
	- eCallIfaceFunc_send_msd
	- eCallIfaceFunc_emergencyCall
are defined.

These functions will be called during a 'run to completion step' (runCycle) of the statechart. 
There are some constraints that have to be considered for the implementation of these functions:
	- never call the statechart API functions from within these functions.
	- make sure that the execution time is as short as possible.
 
*/
extern sc_integer eCallIfaceFunc_aTB2init(const ECall* handle);
extern sc_integer eCallIfaceFunc_init_ecallmessage(const ECall* handle);
extern sc_integer eCallIfaceFunc_init_additionaldata(const ECall* handle);
extern sc_integer eCallIfaceFunc_init_eraGlonass_data(const ECall* handle);
extern sc_integer eCallIfaceFunc_init_eCall_data(const ECall* handle);
extern sc_integer eCallIfaceFunc_setGnssSystem(const ECall* handle);
extern sc_integer eCallIfaceFunc_setLanguage(const ECall* handle);
extern sc_integer eCallIfaceFunc_encode_ecallmessage(const ECall* handle);
extern sc_integer eCallIfaceFunc_encode_optionaldata(const ECall* handle);
extern sc_integer eCallIfaceFunc_play_prompt(const ECall* handle);
extern sc_integer eCallIfaceFunc_send_msd(const ECall* handle);
extern sc_integer eCallIfaceFunc_emergencyCall(const ECall* handle);





#ifdef __cplusplus
}
#endif 

#endif /* ECALLREQUIRED_H_ */
