

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

import javax.swing.JOptionPane;

/**
 * Trivial client for the date server.
 */
public class DateClient {

    /**
     * Runs the client as an application.  First it displays a dialog
     * box asking for the IP address or hostname of a host running
     * the date server, then connects to it and displays the date that
     * it serves.
     */
	//10.38.103.38 myIP
    public static void main(String[] args) throws IOException {
       
        Socket s = new Socket("localhost", 3331);
        BufferedReader input =
            new BufferedReader(new InputStreamReader(s.getInputStream()));
        
        String answer = null;
        char buffer[] = new char[100];
        int num = 0; 
        
        do {
        	System.out.println("Listen...");
        	//num = input.read(buffer);
        	   answer = input.readLine();
        	   System.out.println(answer);
           // System.out.println("letti: " + Integer.toString(num) + " " + new String(buffer));
        } while (answer != null);
        
        System.exit(0);
    }
}