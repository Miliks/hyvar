package reply.speadometer;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class DrawSpeadometer {
	private void jPannel()
	{
		 //JFrame frame = new JFrame( "HyVar Demo" );
		 

	}
public static void main(String [] arg)
{
	 /*JFrame frame = new JFrame( "HyVar Demo" );	
	 frame.setVisible(true);
	 frame.setSize(500, 500);*/
	
	//Create and set up the window.
    JFrame frame = new JFrame("HyvarDemo");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    

    //Display the window.
    frame.pack();
    frame.setVisible(true);
    frame.setSize(500,500);
   // Arc
   // frame.add(comp)
	/* JPanel myPanel =  new JPanel();
	 myPanel.setName("New");
	 myPanel.setSize(100, 100);*/
	 
}
}
